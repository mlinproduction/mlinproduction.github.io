"""
Quick tests to verify that environment has been correctly set up
"""
from collections import OrderedDict
from termcolor import colored

OKGREEN = '\033[92m'
WARNING = '\033[93m'
ENDC = '\033[0m'

def test_jupyter_notebook_and_kernel():
    import nbformat
    import os
    from nbconvert.preprocessors import ExecutePreprocessor

    with open('env_test/env_test.ipynb') as f:
        nb = nbformat.read(f, as_version=4)

    ep = ExecutePreprocessor(timeout=600, kernel_name='ml_in_prod')

    ep.preprocess(nb, {'metadata': {'path': '.'}})

    with open('env_test/executed_env_test.ipynb', 'w', encoding='utf-8') as f:
        nbformat.write(nb, f)

    os.remove('env_test/executed_env_test.ipynb')

def test_pandas():
    import pandas as pd
    import numpy as np
    import tempfile

    with tempfile.TemporaryFile() as f:
        df = pd.DataFrame(np.random.rand(10, 10), columns=["col-%d" % i for i in range(10)])
        df.to_parquet(f)

def test_sklearn():
    # Borrowed from https://scikit-learn.org/stable/auto_examples/classification/plot_digits_classification.html#sphx-glr-auto-examples-classification-plot-digits-classification-py
    from sklearn import datasets, svm, metrics

    digits = datasets.load_digits()

    n_samples = len(digits.images)
    data = digits.images.reshape((n_samples, -1))

    classifier = svm.SVC(gamma=0.001)

    classifier.fit(data[:n_samples // 2], digits.target[:n_samples // 2])

    expected = digits.target[n_samples // 2:]
    predicted = classifier.predict(data[n_samples // 2:])

    report = metrics.classification_report(expected, predicted)

def test_matplotlib():
    import numpy as np
    from matplotlib import pyplot as plt
    import tempfile

    plt.scatter(np.random.rand(10), np.random.rand(10))
    with tempfile.TemporaryFile() as f:
        plt.savefig(f, format='png')

def test_doit():
    import subprocess
    subprocess.run(["doit", "-f", "env_test/dodo.py"])

def test_joblib():
    from joblib import Memory
    memory = Memory('/tmp/')

    def my_f(x):
        return x

    my_f_cached = memory.cache(my_f)

    my_f_cached(10)
    my_f_cached(10)

def test_git():
    import subprocess
    import tempfile

    with tempfile.TemporaryDirectory() as dirname:
        subprocess.run(["git", "init", dirname])

def test_luigi():
    import os
    import luigi

    os.system('sudo luigid --background')

    task = luigi.Task()
    luigi.build([task])

    target_path = 'executed_env_test'
    target = luigi.LocalTarget(path=target_path)
    with target.open('w') as fout:
        fout.write('')

    with target.open('r') as fin:
        _ = fin.read()

    target.fs.remove(target_path)

def test_google_auth():
    import google.auth

def test_google_api_python_client():
    from googleapiclient.discovery import build

def test_google_auth_httplib2():
    import google_auth_httplib2

def test_tensorflow():
    import tensorflow as tf
    hello = tf.constant('Hello, Tensorflow!')
    sess = tf.Session()
    print(sess.run(hello))

def test_keras():
    from keras.models import Sequential
    from keras.layers import Dense
    from keras.utils import to_categorical
    import numpy as np

    x = np.array([[1], [0]])
    y = [1, 0]
    y = to_categorical(y)

    model = Sequential()
    model.add(Dense(2))
    model.compile(loss='binary_crossentropy', optimizer='sgd', metrics=['accuracy'])
    model.fit(x, y, verbose=0)

tests = OrderedDict([
    ('git', test_git),
    ('pandas', test_pandas),
    ('sklearn', test_sklearn),
    ('matplotlib', test_matplotlib),
    ('jupyter_notebooks', test_jupyter_notebook_and_kernel),
    ('doit', test_doit),
    ('joblib.Memory', test_joblib),
    ('luigi', test_luigi),
    ('google_auth', test_google_auth),
    ('google_api_python_client', test_google_api_python_client),
    ('google_auth_httplib2', test_google_auth_httplib2),
    ('tensorflow', test_tensorflow),
    ('keras', test_keras)
])

for (name, test) in tests.items():
    try:
        test()
    except Exception as ex:
        print(colored("Test for {} failed. The package may not be correctly installed. Error:\n{}".format(name, repr(ex)), 'red'))
    else:
        print(colored("Test for {}: OK!".format(name), 'green'))
