def task_echo():
    return {
        'actions': ['echo hi'],
        'verbosity': 2,
        }